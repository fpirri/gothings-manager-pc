#!/bin/bash
#                                                                    2020-02-10
#  Set raspi IP & password
#
#  nomi comuni da usare negli script
source /app/scripts/include/LocalNames.sh
#
#  utility function per passare la pwd agli script (funzione 'no_pass $1')
source /app/scripts/include/SshNoPass.sh
#
echo
echo
echo "---------------------------------------------------------"
echo "Setup raspi password & IP address"
echo
echo "parametri:                                  ELIMINARE !!!"
echo "TargetName: $TargetName"
echo "TargetIp: $TargetIp"
echo "TargetPwd: $TargetPwd"
echo
echo "---------------------------------------------------------"
echo "Environment on this server"
echo "User:     $(whoami)"
echo "WorkDir:  $(pwd)"
echo
echo "Memorizzazione dei parametri della raspberry"
echo
File="/app/scripts/include/targets/TargetDefine"
echo "write in file: $File"
echo
echo "#!/bin/bash" > $File
echo "#                                      $(date)" >> $File
echo "#  Target definition" >> $File
echo "#" >> $File
echo "#  This file is made up by the PC Manager program" >> $File
echo "#  Its purpose is to define the properties of the reachable target boards" >> $File
echo "#" >> $File
echo "#  This file should be sourced by the relevant scripts:" >> $File
echo "#      source ./include/targets/TG_00x" >> $File
echo "#  each script will be tailored to the specified target board" >> $File
echo "TargetName=\"$TargetName\"" >> $File
echo "TargetPwd=\"$TargetPwd\"" >> $File
echo "TargetIp=\"$TargetIp\"" >> $File
echo "#" >> $File
echo
echo "Done."
