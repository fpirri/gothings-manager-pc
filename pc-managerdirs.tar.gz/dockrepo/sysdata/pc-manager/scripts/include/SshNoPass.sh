# shortcut to give password to ssh
#
# requires intallation of sshpass & expect
####  Va messo nel dockerfile !!!!
# ref:  https://stackoverflow.com/questions/12202587/automatically-enter-ssh-password-with-script#comment86056012_47397387
####
#
#######
#  usage: function to ssh with password=PWD_PARAM
#    <-- set PWD_PARAM nello scritp-server
#    $1 <-- user@host
#    $2 <-- comando remoto
#    $3 <-- remote user password
#
ssh_no_pass(){
  export SSHPASS="$3"
  sshpass -e ssh -o PubkeyAuthentication=no "$1" "$2"
}