#!/bin/bash
#                                                                    2021-11-10
#  Display script environment
#
source scripts/include/LocalNames.sh
#
echo
echo "   WorkDir:  ${WorkDir}"
echo " ScriptDir:  ${ScriptDir}"
echo "IncludeDir:  ${IncludeDir}"
echo "UploadsDir:  ${UploadsDir}"
echo "RunnersDir:  ${RunnersDir}"
echo "    LogDir:  ${LogDir}"
echo
echo "---------------------------------------------------------"
echo "Environment on this server"
echo
echo "User:  $(whoami)"
echo "Dir:   $(pwd)"
echo
echo "nodename $(uname -n)"
echo "kernel-name $(uname -s)"
echo "kernel-release $(uname -r)"
echo "kernel-version $(uname -v)"
echo "machine $(uname -m)"
echo "operating-system $(uname -o)"
echo "processor $(uname -p)"
echo "hardware-platform $(uname -i)"
echo
echo "Done."
