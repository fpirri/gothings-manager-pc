#!/bin/bash
#                                                                    2021-11-10
#  Display script environment
#
##########################################################################
pause(){
  #
  #  ask key before continuing (^C is active)
  #    $key:  user input key
  #
  echo "-------------------------------------------------------------- $1/"
  read -rsp $'Please press any key to continue ...' -n 1 key
}
#
continue(){
#  ask for stop processing
#   Y   continue
#   *   stop processing
#
  echo "  yY only == continue"
  read -rsp "Do you like to Continue ? [y/N] " -n 1 key
  case "$key" in
    [yY]) 
      echo
      echo "OK, go on"
      echo
      ;;
    *)
      echo
      echo "It is not 'y' or 'Y', so I exit"
      exit
      ;;
  esac
}
############################################################################
#
source /app/scripts/include/LocalNames.sh
#
echo
echo
echo "WorkDir:     ${WorkDir}"
echo "ScriptDir:   ${ScriptDir}"
echo "IncludeDir:  ${IncludeDir}"
echo "UploadsDir:  ${UploadsDir}"
echo "RunnersDir:  ${RunnersDir}"
echo "LogDir:      ${LogDir}"
echo
echo "---------------------------------------------------------"
echo "Environment on this server"
echo
echo "User:     $(whoami)"
echo "WorkDir:  $(pwd)"
echo
echo "Change owner to default user in user folders and subfolders:"
echo "    ${RunnersDir}"
echo "    ${ScriptDir}"
echo "    ${LogDir}"
echo "... so you can edit/erase them using the PC editor"
echo 
continue
echo
echo "User 1000 on ${RunnersDir}"
sudo chown -R 1000:1000 "${RunnersDir}"
echo
echo "User 1000 on ${ScriptDir}"
sudo chown -R 1000:1000 "${ScriptDir}"
echo
echo "User 1000 on ${LogDir}"
sudo chown -R 1000:1000 "${LogDir}"
echo
echo "Done."
