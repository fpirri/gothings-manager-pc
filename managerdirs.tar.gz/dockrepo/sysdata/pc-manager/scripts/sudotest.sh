#!/bin/bash
#                                                                    2020-02-10
#  prova sudo in script-server
#
ServiceName="script-server"
Home=$home
DockDir="${Home}dockrepo/"
WorkDir="${Home}dockrepo/sysdata/${ServiceName}/"
#
echo
echo
echo "---------------------------------------------------------"
echo "Environment on this server"
echo
echo "User:  $(whoami)"
echo "Dir:   $(pwd)"
echo
echo "nodename $(uname -n)"
echo "kernel-name $(uname -s)"
echo "kernel-release $(uname -r)"
echo "kernel-version $(uname -v)"
echo "machine $(uname -m)"
echo "operating-system $(uname -o)"
echo "processor $(uname -p)"
echo "hardware-platform $(uname -i)"
echo
echo "Network:"
ip a
echo
echo "Done."
