#  File to be sourced in a main script
#
#  RASPI Manager bash names for bugy script server
#
#####################################################################
#
#  This file defines common names
#  It should be sourced at the very top of bash scripts:
#    source /app/scripts/include/local_names.sh
#  you can use the variables below in any script in this server
#
#####################################################################
#                   common & useful names for pc-manager bash scripts
#
ServiceType="pc"
ServiceName="manager"
ServiceFullName="${ServiceType}-${ServiceName}"
Top="/app/"
WorkDir="${Top}"
ScriptDir="${WorkDir}scripts/"
IncludeDir="${ScriptDir}include/"
UploadsDir="${ScriptDir}uploads/"
RunnersDir="${WorkDir}conf/runners/"
LogDir="${WorkDir}logs/"
#
