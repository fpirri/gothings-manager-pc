# shortcut to give password to ssh
#
# requires intallation of sshpass & expect
#
####  Va messo nel dockerfile !!!!
# ref:  https://stackoverflow.com/questions/12202587/automatically-enter-ssh-password-with-script#comment86056012_47397387
####
#
#######
#  usage: function to ssh with password=PWD_PARAM
#    <-- set PWD_PARAM nello scritp-server
#    $1 <-- subdir/file                path a partire da /app/scripts/uploads/
#    $2 <-- pi@<raspi address>         raspi remota
#    $3 <-- subdir                     path a ;partire da /home/pi/dockrepo/
#    $4 <-- remote user password       parametro SSHPASS nel chiamante
#
scp_put_file(){
  export SSHPASS="$4"

######
# Limitazioni (per sicurezza)
#   ${Top}/scripts/uploads/         Dir (locale) di partenza
#   pi@192.168.1.43                 raspi di arrivo
#   /home/pi/dockrepo/              dir (remoto, sulla raspi) di arrivo
#
#####
  RemotePi="pi@192.168.1.43"
  RemoteDir="/home/pi/dockrepo/"
  RemoteSubDir="sysdata/raspi-test/test/"

#  scp /app/scripts/uploads/echotest.sh pi@192.168.1.43:/home/pi/dockrepo/sysdata/raspi-test/test/
  echo "---------------------------------------------"
  echo
  echo "chiamata:"
  echo  "${UploadsDir}$1" "$2:${RemoteDir}$3"
  echo
  scp "${UploadsDir}$1" "$2:${RemoteDir}$3"
  echo
  echo "---------------------------------------------"

}