#!/bin/bash
#                                                                    2021-11-10
#  Hello World Test
#
echo
echo "Hello World !"
echo
echo "This is the standard test to verify basic functioning of programs"
echo
echo "It means that the system is capable of showing information to the world"
echo "   (It is not much, but it is the beginning of life ...)"
